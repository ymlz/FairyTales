<?php
//on 为开启
//off&其他 为关闭

$GLOBALS['isAutoNav'] = 'off'; //自动设置导航栏中 margin 及 width 值（推荐开启）
$GLOBALS['isIconNav'] = 'off'; //将导航栏中的 1,2,3 替换成 Emoji 图标

$GLOBALS['style_BG'] = 'https://ws4.sinaimg.cn/large/0078tOkRgy1fx1rj4p80ij31kw11x17i.jpg'; //背景图设置。填入图片 URL 地址，留空为关闭
?>